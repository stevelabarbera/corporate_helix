from copy import deepcopy
from .signals import extract_signals
from .policies import get_policy

def evaluate_candidate(graph,left,right,policy_name):
    p=deepcopy(get_policy(policy_name)); s=extract_signals(graph,left,right)
    hc=[x for x in p.get("hard_confirms",[]) if s.get(x) is True]
    hx=[x for x in p.get("hard_conflicts",[]) if s.get(x) is True]
    score=0.0; contrib=[]
    for sig,w in p.get("weights",{}).items():
        if s.get(sig) is True:
            score+=w; contrib.append({"signal":sig,"value":True,"contribution":w})
    for sig,w in p.get("numeric_weights",{}).items():
        v=s.get(sig)
        if v is not None:
            c=round(float(v)*w,4);score+=c;contrib.append({"signal":sig,"value":round(float(v),4),"contribution":c})
    for sig,w in p.get("penalties",{}).items():
        if s.get(sig) is True:
            score+=w;contrib.append({"signal":sig,"value":True,"contribution":w})
    review=False
    if hx: decision,reason="REJECT","hard_conflict"
    elif hc: decision,reason="ACCEPT","hard_confirm"
    elif score>=p["thresholds"]["auto_accept"]: decision,reason="ACCEPT","score_threshold"
    elif score>=p["thresholds"]["review"]: decision,reason="REVIEW","score_threshold"; review=True
    else: decision,reason="REJECT","score_threshold"
    guards=[]
    for g in p.get("guards",[]):
        if s.get(g.get("when")) is True and g.get("effect")=="cap_at_review" and decision=="ACCEPT":
            decision,reason,review="REVIEW","guard",True
            guards.append({"guard":g["name"],"effect":"cap_at_review","trigger_signal":g["when"]})
    if decision=="REVIEW": review=True
    return {"policy":p["name"],"left_node_id":left.get("node_id"),"right_node_id":right.get("node_id"),
            "left_name":left.get("canonical_name"),"right_name":right.get("canonical_name"),
            "signals":s,"hard_confirms":hc,"hard_conflicts":hx,"score":round(score,4),
            "contributions":contrib,"guard_events":guards,"decision":decision,
            "decision_reason":reason,"review_required":review,"adjudication_status":"DETERMINISTIC_ONLY"}
