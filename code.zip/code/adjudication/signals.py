from .similarity import levenshtein_ratio,jaccard_tokens

def _addresses(node):
    out=set()
    for ent in node.get("source_entities") or []:
        for addr in ent.get("addresses") or []:
            if addr: out.add(" ".join(addr.casefold().split()))
    return out

def _ids(node):
    return {x for x in node.get("provider_entity_ids") or [] if x}

def _aliases(node):
    return {a.get("name_normalized") for a in node.get("aliases") or [] if a.get("name_normalized")}

def _ownership_edges(graph,lid,rid):
    out=[]
    for rel in graph.get("relationships") or []:
        s,o=rel.get("subject_node_id"),rel.get("object_node_id")
        if (s==lid and o==rid) or (s==rid and o==lid): out.append(rel)
    return out

def extract_signals(graph,left,right):
    ln,rn=left.get("canonical_name_normalized"),right.get("canonical_name_normalized")
    lb,rb=left.get("legal_name_base"),right.get("legal_name_base")
    lj,rj=left.get("jurisdiction"),right.get("jurisdiction")
    li,ri=_ids(left),_ids(right)
    la,ra=_aliases(left),_aliases(right)
    shared=sorted(_addresses(left)&_addresses(right))
    edges=_ownership_edges(graph,left.get("node_id"),right.get("node_id"))
    return {
      "exact_normalized_name": bool(ln and rn and ln==rn),
      "exact_legal_name_base": bool(lb and rb and lb==rb),
      "levenshtein_ratio": levenshtein_ratio(ln,rn),
      "token_jaccard": jaccard_tokens(ln,rn),
      "jurisdiction_match": bool(lj and rj and lj==rj),
      "jurisdiction_conflict": bool(lj and rj and lj!=rj),
      "exact_provider_identifier": bool(li&ri),
      "provider_identifier_conflict": bool(li and ri and not(li&ri)),
      "explicit_former_name_match": bool((rn in la if rn else False) or (ln in ra if ln else False)),
      "shared_address": bool(shared),
      "shared_addresses": shared,
      "explicit_subsidiary_edge": any(e.get("predicate")=="SUBSIDIARY_OF" for e in edges),
      "ownership_percentages":[e.get("ownership_percent") for e in edges if e.get("ownership_percent") is not None],
      "left_provider_ids":sorted(li),
      "right_provider_ids":sorted(ri)
    }
